package exam.programming;

public class Q3 {
	public static void main(String[] args) {
		// Arrays of test strings...
		String[] balanced = {"", "()", "()()", "(())", "(()())"};
		String[] notBalanced = {")(", ")()(", "(()", "()((", "()))"};    
				
		// Should print true for these strings...
		for (int i = 0; i < balanced.length; i++)
			System.out.println("\"" + balanced[i] + "\" - " + isBalanced(balanced[i]));
		
		System.out.println();
		
		// Should print false for these strings...
		for (int i = 0; i < notBalanced.length; i++)
			System.out.println("\"" + notBalanced[i] + "\" - " + isBalanced(notBalanced[i]));
		
	}
	
	// Returns true if a string of parentheses is correctly balanced; false otherwise.
	// Assume p contains only '(' and ')' characters.
	public static boolean isBalanced(String p) {
		return false;
	}
}
